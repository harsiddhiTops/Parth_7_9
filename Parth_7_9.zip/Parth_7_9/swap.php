<?php
$a = 2;
$b = 3;

//swap  $a= 3;$b =2


$temp = $a;

$a=$b;

$b = $temp;

echo $a."<br>";

echo $b 



?>