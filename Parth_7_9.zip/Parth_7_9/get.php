<?php
if(isset($_GET['submit']))
{

$email = 	$_GET['email'];

$password = $_GET['password'];

echo $email . "<br>";

echo $password;

}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Demo app </title>
</head>
<body>

	<form method="get">
		<table>
			<tr>
				<td>Email</td>
				<td>
			<input type="email" name="email">
		</td>

	</tr>
	<tr><td>Password</td><td>
	<input type="password" name="password"></td>
</tr>

	<tr>
		<td>
		<input type="submit" name="submit"></td>
</tr>

			<br>
		</table>

	</form>

</body>
</html>