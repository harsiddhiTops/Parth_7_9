<?php

$x = 1;

if($x == 1)
{
	echo "x is 1"."<br>";
	$x = ++$x;

	if($x == 2)
	{
		echo "x is 2"."<br>";
	}
	//echo $x ;
}
elseif ($x == 2) {
	# code...

	echo "x is 2"."<br>";
	$x ++ ;
}

elseif ($x == 3) {
	# code...

	echo "x is 3"."<br>";
}

elseif ($x == 4) {
	# code...

	echo "x is 4"."<br>";
}

else
{
	echo "else block";
}
?>