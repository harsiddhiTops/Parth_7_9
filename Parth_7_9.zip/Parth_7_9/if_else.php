<?php

$x = 9;

if($x == 4)
{
	echo "x is 4"."<br>";
	$x++;
}

else
{
	echo "else block";
}
// if($x == 5)
// {
// 	echo "x is 5"."<br>";
// }
?>