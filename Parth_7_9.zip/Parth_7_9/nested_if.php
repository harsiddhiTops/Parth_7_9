<?php 

$x = 4;
if($x == 4)
{
	echo "x is 4"."<br>";
	$x++;

	 if($x == 5) // nested if 
	 {
	 	echo "x is 5 ";
	 }
	 else
	 {
	 	echo "i am in if else";
	 }
}
?>