<?php

include '../header.php';    // warning

//include_once('header.php');



//require('../header.php');   // wrong path error 

//require_once("header.php");










?>