<?php

$x = 2;

do
{

$x++; // increment
echo $x."<br>";
}while($x <5);

?>