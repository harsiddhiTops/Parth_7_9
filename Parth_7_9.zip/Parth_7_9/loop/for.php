<?php

for($i=1;$i<=3;$i++)
{

	//echo "Hello Tops "."<br>";

}


//nested loop 


for($i=1;$i<=3;$i++)
{

	for($j=1;$j<=2;$j++)
	{
		echo "Hello Tops "."<br>";
	}

	echo "****New Row****"."<br>";
	

}

?>