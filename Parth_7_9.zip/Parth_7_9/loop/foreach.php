<?php

$name = array(); // array declare
$name[0] = "Tops Tecnology";
$name[1] = "harsiddhi";
$name[2] = "PHP";

//print_r($name);

foreach ($name as $key) {


	echo "value of array is ".$key."<br>" ;
	# code...
}

?>