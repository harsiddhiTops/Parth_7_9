<?php

$name = "tops";
function demo()
{
	$x = 5;    //local

	global $name;

	echo "i am in demo function".$x ."<br>";

	echo $name ;// error if  not use global keyword
}

demo();

echo $name ; // global 

 // echo $x;  // error for local variable
?>