<?php

echo "Hello Tops"."<br>";

echo "Hi"."<br>";
print_r("Hi i am harsiddhi");

echo "abc"."xyz"."<br>";

?>