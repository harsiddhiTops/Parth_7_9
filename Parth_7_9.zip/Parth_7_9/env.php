<?php

print_r($_ENV);

?>