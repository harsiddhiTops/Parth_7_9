<?php

$nm = array('red'=>"a", // assoc array
	'green'=>"b",
	'blue'=>"c"


	);
print_r(array_search('b',$nm));




?>