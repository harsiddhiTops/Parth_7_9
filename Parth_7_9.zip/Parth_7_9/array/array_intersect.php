<?php
$color = array(
		'r'=>"red",
		'g'=>"tops technology",
		'b'=>"blue"
        );

//print_r($color);

$color1 = array(
		'r'=>"red",
		'g'=>"green",
		'b'=>"blue"
        );

print_r(array_intersect($color, $color1));



// $name = array(
// 		'a'=>"parth",
// 		'b'=>"sursingh",
// 		'c'=>"tops"
//         );

        ?>