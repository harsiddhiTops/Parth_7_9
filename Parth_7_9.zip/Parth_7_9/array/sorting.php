<?php
$a = array(1,2,3,7,4,9,4);
print_r($a);

print_r(sort($a));



?>