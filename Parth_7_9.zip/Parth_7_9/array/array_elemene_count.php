<?php
$numerical_arr = array(1,3,2,5,4,2,3,2,3,2,2);

print_r(array_count_values($numerical_arr));



?>