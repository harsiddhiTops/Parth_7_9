<?php

$my_array = array("Tops","PHP","Students","JAVA");

$length = count($my_array);
$length1= sizeof($my_array);

//print_r($length);
print_r($length1);

?>