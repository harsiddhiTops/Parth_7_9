<?php
$color = array(
		'r'=>"red",
		'g'=>"green",
		'b'=>"blue"
        );

//print_r($color);

$name = array(
		'a'=>"parth",
		'b'=>"sursingh",
		'c'=>"tops"
        );

//print_r($name);

// array_combine and array merge 

$data = array_combine($color,$name);

$merge = array_merge($color,$name);

print_r($merge); 



//print_r($data);  // output of array combine 








?>