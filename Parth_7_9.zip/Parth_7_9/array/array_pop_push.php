<?php
$numeric_array = array("1","2","3","5","8");

print_r($numeric_array);
echo "<br>";
array_pop($numeric_array);
echo "<br>";

print_r($numeric_array);

array_push($numeric_array,12);
echo "<br>";
print_r($numeric_array);







?>