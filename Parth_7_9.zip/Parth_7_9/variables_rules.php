<?php

$test = "harsiddhi";


// $120 = "Tops Technology"; // error 

// echo $120;
$a123 = "Tops";

$_name = "Exam";

echo $_name."<br>";


echo $a123."<br>";



echo $test;





?>