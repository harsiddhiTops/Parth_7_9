<?php

$a = 4; // assign 

$b = "Tops";


$b .= $a ; 


$c= 6.89;

// $a = $a + $c ;


//plus 


echo "a var is " . $a ."<br>";

echo "b var is " . $b ."<br>";

$a += $c;

echo "a var is after plus " . $a ."<br>";

$a *= $c;

echo "a var is after Mul " . $a ."<br>";


$a -= $c;

echo "a var is after min " . $a ."<br>";


$a /= $c;

echo "a var is after div " . $a ."<br>";




?>