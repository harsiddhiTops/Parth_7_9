<?php

$a = 4;

$b= 6;

if($a <20 && $a > 2)
{
	echo "a is "."$a"."<br>";
}

if($a <20 | $a > 40)
{
	echo "a is again  "."$a"."<br>";
}

if(!($a == $b))
{
	echo " Not condition Woking now";
}




?>