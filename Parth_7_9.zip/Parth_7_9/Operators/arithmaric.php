<?php

$a = 30;

// echo $A ; //Not working

$b = 10;

$sum = $a + $b ;

$sub = $a - $b ;

$mul = $a * $b ;

$div = $a/$b ;

$mod = $a % $b;
echo "sum is" . $sum ."<br>";

echo "sub is" . $sub ."<br>";

echo "multiplication is" . $mul."<br>";


echo "mod is " .$mod."<br>";

echo "dived  is" . $div ."<br>";

echo "increment"."<br>";
$div++;

echo $div ."<br>";

++$div;

echo $div ."<br>";

echo "decrement"."<br>";


$div--;

echo $div ."<br>";


--$div;

echo $div ."<br>";





?>