<?php
if(isset($_POST['submit']))
{

$email = 	$_POST['email'];

$password = $_POST['password'];

echo $email . "<br>";

echo $password;

}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Demo app </title>
</head>
<body>

	<form method="post">
		<table>
			<tr>
				<td>Email</td>
				<td>
			<input type="email" name="email">
		</td>

	</tr>
	<tr><td>Password</td><td>
	<input type="password" name="password"></td>
</tr>

	<tr>
		<td>
		<input type="submit" name="submit"></td>
</tr>

			<br>
		</table>

	</form>

</body>
</html>