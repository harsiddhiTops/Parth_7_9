<?php 
if(isset($_POST['submit']))
{
echo "on click ";


print_r($_FILES);
}	

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<form method="POST" enctype="multipart/form-data">
		<table>
			<tr><td>
			<input type="email" name="email" placeholder="enter email">

		</td>
	</tr>
	<tr>
		<td>
			<input type="password" name="password" placeholder="enter password">
		</td>
	</tr>

	<tr>
		<td>
			<input type="file" name="upfile">
		</td>
	</tr>

	<tr>
		<td>
			<input type="submit" name="submit">
		</td>
	</tr>

	
		</table>
		
	</form>
<a href="logout.php">Logout</a>
</body>
</html>