<?php
$x = 13;

switch ($x) {
	case '1':
		# code...

	echo "x is 1";
		break;

		case '2':
		# code...

	echo "x is 2";
	
	default:
		# code...

	echo "no value";
		break;
}
?>