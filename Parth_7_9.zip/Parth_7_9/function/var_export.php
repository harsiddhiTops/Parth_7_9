<?php

$name = array("tops","Ahmedabad","PHP","java");

//print_r($name);


echo "<br>"."Now we use export ";

 var_export($name);
?>