<?php

function sum($a,$b)
{

	$c = $a + $b ;

	return $c;
	//echo "sum is :" .$c ."<br>";
}

function sub($a,$b)
{
$c = $a - $b ;
return $c;
	//echo "sub is :" .$c ."<br>";
}

function mul($a,$b)
{
$c = $a * $b ;
return $c;
	//echo "mul is :" .$c ."<br>";
}

function div($a,$b)
{
$c = $a / $b ;
return $c;
	//echo "div is :" .$c ."<br>";
}

$a = 30;
$b = 10;

$result = sum($a,$b); //argument pass 

echo $result."<br>" ;


echo sub($a,$b); // parameter pass in function 

echo "<br>";

echo mul($a,$b);
echo "<br>";


echo div($a,$b);
echo "<br>";

?>