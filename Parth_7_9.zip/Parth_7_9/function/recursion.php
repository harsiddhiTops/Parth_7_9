<?php
function factorial($no)
{
	if($no < 2)
	{
 		return 1;
	}
	else
	{
		$no = $no * factorial($no-1);
		return $no;
	}
}

$ans = factorial(5);

echo $ans;
?>