<?php

function array_return()
{

	$name = array("Tops","PHP","JAVA","C");

	return $name;

}

print_r(array_return());



?>