<?php

function sum($a,$b)
{

	$c = $a + $b ;
	echo "sum is :" .$c ."<br>";
}

function sub($a,$b)
{
$c = $a - $b ;
	echo "sub is :" .$c ."<br>";
}

function mul($a,$b)
{
$c = $a * $b ;
	echo "mul is :" .$c ."<br>";
}

function div($a,$b)
{
$c = $a / $b ;
	echo "div is :" .$c ."<br>";
}

$a = 30;
$b = 10;

sum($a,$b); //argument pass 


sub($a,$b); // parameter pass in function 

mul($a,$b);

div($a,$b);

?>