<?php

function demo()
{
	echo "Hello World";
}

demo();
?>