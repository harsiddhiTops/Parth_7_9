<?php

$name = array("tops","Ahmedabad","PHP","java");

print_r($name);


echo "<br>"."Now we use var dump";


var_dump($name);

?>