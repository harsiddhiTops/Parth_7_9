<?php
//default argument
function person($name,$city,$course = "PHP")
{
		echo $name."<br>";

		echo $city = "Ahmedabd"."<br>";

		echo $course;
}
person("sursingh","Ahmedabad","JAVA");

?>