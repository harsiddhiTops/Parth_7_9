<?php
if(isset($_GET['submit']))
{
		echo "submit button clicked";
}
?>


<!DOCTYPE html>
<html>
<head>
	<title>Demo app </title>
</head>
<body>

	<form method="get">
		<table>
			<tr>
				<td>Email</td>
				<td>
			<input type="email" name="email">
		</td>

	</tr>
	<tr><td>Password</td><td>
	<input type="password" name="password"></td>
</tr>

	<tr>
		<td>
		<input type="submit" name="submit"></td>
</tr>

			<br>
		</table>

	</form>

</body>
</html>