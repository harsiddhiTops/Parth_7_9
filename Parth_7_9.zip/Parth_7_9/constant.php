<?PHP
define("NAME","Tops Technology")
;


echo NAME;
?>