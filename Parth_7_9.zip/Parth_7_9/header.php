<?php ?>

<!DOCTYPE html>
<html>
<head>
	<title>Header</title>
	<style type="text/css">
		.header
		{
			width: 100%;
			height: 30px;
			margin-top: 5px;
			background-color: red;
		}
	</style>
</head>
<body>
<div class="header" name="header">
</body>
</html>