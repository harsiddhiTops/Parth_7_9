<?php 



// static 
function demo()
{
static $x;

$x = 5;

$x++;

echo $x;
}

demo();

demo();

?>