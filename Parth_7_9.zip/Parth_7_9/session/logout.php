<?php
session_start();

//echo $_SESSION['email'];

session_unset();
session_destroy();

header('Location:session.php')

?>