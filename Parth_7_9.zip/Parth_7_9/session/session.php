<?php
session_start();

if(isset($_POST['submit']))
{
echo "on click ";

$_SESSION['email'] = $_POST['email'];

echo $_SESSION['email'];
}	
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<form method="POST">
		<table>
			<tr><td>
			<input type="email" name="email" placeholder="enter email">

		</td>
	</tr>
	<tr>
		<td>
			<input type="password" name="password" placeholder="enter password">
		</td>
	</tr>

	<tr>
		<td>
			<input type="submit" name="submit">
		</td>
	</tr>
		</table>
		
	</form>
<a href="logout.php">Logout</a>
</body>
</html>