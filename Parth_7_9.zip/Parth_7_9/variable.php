<?php

$a="harsiddhi";

echo $a."<br>";

$b = 5;


$b++; //Post increment
++$b; //pre increment

echo $b;

?>