<?php
$name = "user";

$value = "Tops Technology";

setcookie($name,$value,time());

if(isset($_COOKIE[$name]))
{
	echo "cookie set";
}
else
{
	echo " not set";
}
?>