<?php

$str = "Hello";

//$reverse = strrev($str); // using function 

//echo $reverse;


// For Hello 

//echo $reverse[0];

// without function 

$length = strlen($str);
for($i = $length-1;$i>=0;$i--)
{
	$output[] = $str[$i];

}

print_r($output);
?>

